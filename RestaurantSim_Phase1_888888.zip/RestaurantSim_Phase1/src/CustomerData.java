public class CustomerData {
    public int id;
    public String arrivalTime;
    public String order;
    public int tableNumber;

    public CustomerData(int id, String arrivalTime, String order) {
        this.id = id;
        this.arrivalTime = arrivalTime;
        this.order = order;
    }
}
