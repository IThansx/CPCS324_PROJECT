public class TimeUtil {
    private static int simulatedMinutes = 0;

    public static String getCurrentTime() {
        int hour = 9 + simulatedMinutes / 60;
        int minute = simulatedMinutes % 60;
        return String.format("%02d:%02d", hour, minute);
    }

    public static int getCurrentTimeValue() {
        return simulatedMinutes;
    }

    public static void setCurrentTime(int t) {
        simulatedMinutes = t;
    }

    public static void reset() {
        simulatedMinutes = 0;
    }

    public static void advanceTime(int minutes) {
        simulatedMinutes += minutes;
    }

    public static int getSimulatedMinutes() {
        return simulatedMinutes;
    }

    public static String addMinutes(String time, int minutesToAdd) {
        String[] parts = time.split(":");
        int hour = Integer.parseInt(parts[0]);
        int minute = Integer.parseInt(parts[1]);

        minute += minutesToAdd;
        while (minute >= 60) {
            minute -= 60;
            hour++;
        }

        return String.format("%02d:%02d", hour, minute);
    }
    
    public static int convertToMinutes(String timeStr) {
    String[] parts = timeStr.split(":");
    int hour = Integer.parseInt(parts[0]);
    int minute = Integer.parseInt(parts[1]);

    return (hour - 9) * 60 + minute; // 09:00 هي البداية (0)
}

}
