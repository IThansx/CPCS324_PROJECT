public class Chef {
    public String name;
    public int chefNumber;
    public boolean isBusy = false;

    public Chef(String name, int chefNumber) {
        this.name = name;
        this.chefNumber = chefNumber;
    }

    public int getPrepTime(String meal) {
        meal = meal.toLowerCase();
        switch (meal) {
            case "salad": return 5;
            case "burger": return 8;
            case "pizza": return 10;
            case "pasta": return 10;
            case "steak": return 8;
            case "sushi": return 5;
            case "tacos": return 5;
            case "soup": return 10;
            default: return 7;
        }
    }
}

