import java.util.LinkedList;
import java.util.Queue;
import java.util.concurrent.Semaphore;

public class Buffer {
    private final int capacity;
    private final Queue<BufElement> queue = new LinkedList<>();

    // Semaphores
    private final Semaphore mutex = new Semaphore(1);    
    private final Semaphore items = new Semaphore(0);       
    private final Semaphore spaces;                         

    public Buffer(int capacity) {
        this.capacity = capacity;
        this.spaces = new Semaphore(capacity);
    }

    public void produce(BufElement item, String producerName) throws InterruptedException {
        spaces.acquire(); 
        mutex.acquire(); 

        queue.add(item);


        mutex.release(); 
        items.release();  
    }

    public BufElement consume(String consumerName) throws InterruptedException {
        items.acquire(); 
        mutex.acquire();

        BufElement item = queue.poll();


        mutex.release();
        spaces.release(); 

        return item;
    }
}