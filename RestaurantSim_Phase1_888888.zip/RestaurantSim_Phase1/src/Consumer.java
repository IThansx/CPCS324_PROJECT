public interface Consumer {
    BufElement consume(String consumerName) throws InterruptedException;
}
