public class Event implements Comparable<Event> {
    public int time; // الوقت بالدقائق من بداية اليوم (مثلاً 09:00 = 0)
    public String type; // نوع الحدث: ARRIVAL, ORDER, PREP_START, PREP_DONE, SERVE, EAT, LEAVE
    public CustomerData customer;

    public Event(int time, String type, CustomerData customer) {
        this.time = time;
        this.type = type;
        this.customer = customer;
    }

    @Override
    public int compareTo(Event other) {
        return Integer.compare(this.time, other.time);
    }

    @Override
    public String toString() {
        return String.format("[Time=%d, Type=%s, CustomerID=%d]", time, type, customer.id);
    }
}
