/* -------------------------------------------------------

- GROUP NUMBER 9 -

GROUP MEMBER:
NAME: Wojood Hassan Alzahrani ID: 2208254
NAME: Fatimah Khalid Aljifry  ID: 2221449
NAME: Hanin Alkayyal          ID: 2205461

 */
import java.util.*;

public class RestSimApp {
    public static void main(String[] args) {
        String inputFile = "restaurant_simulation_input3.txt";

        List<CustomerData> customers = InputReader.readCustomerData(inputFile);

        int numChefs = 3;
        int numWaiters = 4;
        int numTables = 5;

        Buffer orderedMealBuffer = new Buffer(10);
        Buffer cookedMealBuffer = new Buffer(10);
        Buffer tableBuffer = new Buffer(numTables);

        for (int i = 0; i < customers.size(); i++) {
            customers.get(i).tableNumber = (i % numTables) + 1;
        }

        PriorityQueue<Event> eventQueue = new PriorityQueue<>();

        for (CustomerData c : customers) {
            int arrivalTime = TimeUtil.convertToMinutes(c.arrivalTime);
            eventQueue.add(new Event(arrivalTime, "ARRIVAL", c));
        }

        System.out.printf("Simulation Started with %d Chefs, %d Waiters, and %d Tables.\n\n",
                numChefs, numWaiters, numTables);

        // Events processing loop
        while (!eventQueue.isEmpty()) {
            Event event = eventQueue.poll();
            TimeUtil.setCurrentTime(event.time);

            CustomerData customer = event.customer;

            switch (event.type) {
                case "ARRIVAL":
                    System.out.printf("[%s] Customer %d is seated at Table %d.\n",
                            TimeUtil.getCurrentTime(), customer.id, customer.tableNumber);

                    // بعد دقيقة يطلب
                    int orderTime = event.time + 1;
                    eventQueue.add(new Event(orderTime, "ORDER", customer));
                    break;

                case "ORDER":
                    System.out.printf("[%s] Customer %d places an order: %s\n",
                            TimeUtil.getCurrentTime(), customer.id, customer.order);

                    // بعد وقت التحضير
                    int prepTime = getPrepTime(customer.order);
                    int prepStartTime = event.time + 1; // التحضير يبدأ بعد دقيقة من الطلب
                    int prepDoneTime = prepStartTime + prepTime;
                    eventQueue.add(new Event(prepDoneTime, "PREP_DONE", customer));
                    break;

                case "PREP_DONE":
                    System.out.printf("[%s] Chef completes preparation for Customer %d's order: %s\n",
                            TimeUtil.getCurrentTime(), customer.id, customer.order);

                    // التقديم للعميل
                    int serveTime = event.time + 1; // التقديم بعد دقيقة من التحضير
                    eventQueue.add(new Event(serveTime, "SERVE", customer));
                    break;

                case "SERVE":
                    System.out.printf("[%s] Waiter serves %s to Customer %d at Table %d\n",
                            TimeUtil.getCurrentTime(), customer.order, customer.id, customer.tableNumber);

                    // بعد التقديم، يغادر العميل بعد وقت معين (مثلاً 10 دقائق من التقديم)
                    int leaveTime = event.time + 10;
                    eventQueue.add(new Event(leaveTime, "LEAVE", customer));
                    break;

                case "LEAVE":
                    System.out.printf("[%s] Customer %d leaves the restaurant after enjoying their meal.\n",
                            TimeUtil.getCurrentTime(), customer.id);
                    break;
            }

            try {
                Thread.sleep(100); // Delay for visualization
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        System.out.println("\n[End of Simulation]");

        // ملخص (مؤقت)
        int totalCustomers = customers.size();
        int totalPrepTime = 0;
        int totalWaitTime = 0;
        int tableWait = 4;

        for (CustomerData customer : customers) {
            int prep = getPrepTime(customer.order);
            totalPrepTime += prep;
            totalWaitTime += (prep + tableWait);
        }

        System.out.println("\nSimulation Summary:");
        System.out.println("Total customers served: " + totalCustomers + " customer(s)");
        System.out.println("Total wait time (including table and meal wait time): " + totalWaitTime + " minute(s)");
        System.out.println("Average wait time (including table and meal wait time): " + (totalWaitTime / totalCustomers) + " minute(s)");
        System.out.println("Total preparation time: " + totalPrepTime + " minute(s)");
        System.out.println("Average preparation time: " + (totalPrepTime / totalCustomers) + " minute(s)");
        System.out.println("Simulation Time: " + TimeUtil.getSimulatedMinutes() + " minute(s)");
    }

    private static int getPrepTime(String meal) {
        meal = meal.toLowerCase();
        switch (meal) {
            case "salad": return 5;
            case "burger": return 8;
            case "pizza": return 10;
            case "pasta": return 10;
            case "steak": return 8;
            case "sushi": return 5;
            case "tacos": return 5;
            case "soup": return 10;
            default: return 7;
        }
    }
}
