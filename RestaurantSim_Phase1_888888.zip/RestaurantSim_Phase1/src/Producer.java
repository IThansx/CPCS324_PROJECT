public interface Producer {
    void produce(BufElement item, String producerName) throws InterruptedException;
}
