public class Waiter {
    public String name;
    public int waiterNumber;
    public boolean isBusy = false;

    public Waiter(String name, int waiterNumber) {
        this.name = name;
        this.waiterNumber = waiterNumber;
    }
}
