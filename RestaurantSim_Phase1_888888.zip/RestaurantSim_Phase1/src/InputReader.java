import java.io.*;
import java.util.*;

public class InputReader {
    public static List<CustomerData> readCustomerData(String filename) {
        List<CustomerData> customers = new ArrayList<>();
        
        try (BufferedReader reader = new BufferedReader(new FileReader(filename))) {
            String line;
            String[] command;
            
            // قراءة أول سطرين (الإعدادات)
            line = reader.readLine(); // Read first line (we assume NC=, NW=, etc)
            String[] settings = line.split(" ");
            int numChefs = Integer.parseInt(settings[0].split("=")[1]);
            int numWaiters = Integer.parseInt(settings[1].split("=")[1]);
            int numTables = Integer.parseInt(settings[2].split("=")[1]);

            line = reader.readLine(); // Read second line (meal prep times)
            String[] mealInfo = line.split(" ");
            // You can skip meal prep parsing for now if it's not used, or handle it
            // Example: read meal times and store them in a map for future use if needed

            // قراءة معلومات العملاء
            while ((line = reader.readLine()) != null) {
                if (line.trim().isEmpty() || line.startsWith("#")) continue;

                command = line.split(" ");
                int id = -1;
                String arrivalTime = "";
                String meal = "";

                for (String part : command) {
                    if (part.startsWith("CustomerID=")) {
                        id = Integer.parseInt(part.substring(11));
                    } else if (part.startsWith("ArrivalTime=")) {
                        arrivalTime = part.substring(12); // Keep it as string
                        // تعديل قراءة الوقت ليكون متوافق مع التنسيق الصحيح
                        if (arrivalTime.length() == 4) {
                            arrivalTime = "0" + arrivalTime; // Adding leading zero
                        }
                    } else if (part.startsWith("Order=")) {
                        meal = part.substring(6);
                    }
                }

                // إضافة العميل إلى القائمة بعد التحقق من صحة البيانات
                if (id != -1 && !arrivalTime.isEmpty() && !meal.isEmpty()) {
                    CustomerData customer = new CustomerData(id, arrivalTime, meal);
                    customers.add(customer);
                }
            }

        } catch (IOException e) {
            e.printStackTrace();
        }

        return customers;
    }
}
