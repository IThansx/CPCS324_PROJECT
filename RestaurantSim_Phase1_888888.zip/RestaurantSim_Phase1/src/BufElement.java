public class BufElement {
    public String value;

    public BufElement(String value) {
        this.value = value;
    }
}
